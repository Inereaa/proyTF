Search.appendIndex(
    [
                {
            "fqsen": "\\existe\u0028\u0029",
            "name": "existe",
            "summary": "Comprueba\u0020si\u0020un\u0020usuario\u0020existe\u0020en\u0020el\u0020archivo\u0020\u0060usuarios.ini\u0060.",
            "url": "namespaces/default.html#function_existe"
        },                {
            "fqsen": "\\grabar\u0028\u0029",
            "name": "grabar",
            "summary": "Guarda\u0020un\u0020usuario\u0020y\u0020su\u0020contrase\u00F1a\u0020en\u0020el\u0020archivo\u0020\u0060usuarios.ini\u0060.",
            "url": "namespaces/default.html#function_grabar"
        },                {
            "fqsen": "\\registrar\u0028\u0029",
            "name": "registrar",
            "summary": "Registra\u0020un\u0020usuario,\u0020crea\u0020su\u0020carpeta\u0020de\u0020trabajo,\u0020y\u0020genera\u0020su\u0020archivo\u0020de\u0020muro.",
            "url": "namespaces/default.html#function_registrar"
        },                {
            "fqsen": "\\acceder\u0028\u0029",
            "name": "acceder",
            "summary": "Verifica\u0020el\u0020acceso\u0020de\u0020un\u0020usuario\u0020mediante\u0020su\u0020nombre\u0020y\u0020contrase\u00F1a.",
            "url": "namespaces/default.html#function_acceder"
        },                {
            "fqsen": "\\",
            "name": "\\",
            "summary": "",
            "url": "namespaces/default.html"
        }            ]
);
