
<form>
    <label> Usuario </label>
    <input type="text" name="usuario" />
    <label> Clave </label>
    <input type="password" name="clave" />
    <input type="submit" name="accion" value="Acceder" />
    <input type="submit" name="accion" value="Registrarme" />
</form>
